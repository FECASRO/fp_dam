/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package porcentajes;

import java.util.Scanner;

/**
 *
 * @author FELIPE
 */
public class alumnosDam {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float matProg, matDesarrollo, matBases;
        int a, b, c, suma;
        Scanner scn = new Scanner(System.in);

        System.out.println(" DAME ALUMNOS DE CADA ASIGNATURA...");
        System.out.println("Alumnos de PROGRAMACION: ");
        a = scn.nextInt();
        System.out.println("Alumnos de ENTORNOS DE DESARROLLO: ");
        b = scn.nextInt();
        System.out.println("Alumnos de BASES DE DATOS: ");
        c = scn.nextInt();
        suma = a + b + c;
        matProg = (a * 100) / suma;
        matDesarrollo = (b * 100) / suma;
        matBases = (c * 100) / suma;

        System.out.println("Estos son los porcentajes de alumnos de cada materia: ");
        System.out.printf("\n PORCENTAJE DE ALUMNOS DE PROGRAMACION: %.1f", matProg);
        System.out.printf("\n PORCENTAJE DE ALUMNOS DE ENTORNOS DE DESARROLLO: %.1f", matDesarrollo);
        System.out.printf("\n PORCENTAJE DE ALUMNOS DE BASES DE DATOS: %.1f", matBases);
    }
}
