/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package perreo;

/**
 *
 * @author FELIPE
 */
public class enumeracion {

    /**
     * @param args the command line arguments
     */
    enum perro {
        Mastín, Terrier, Bulldog, Pekines, Caniche, Galgo
    }
//aqui esta la enumeracion con los valores que pueden adoptar las variables

    public static void main(String[] args) {

// Asigno valores a la variable
        perro var1 = perro.Mastín;
        perro var2 = perro.Caniche;
        // Muestra los resultados      
        System.out.println("Los perros a comparar hoy son:");
        System.out.println("Primero: " + var1+" y ocupa la posicion: "+ var1.ordinal());
        System.out.println("Segundo: " + var2+" y ocupa la posicion: "+var2.ordinal());
// Comparacion de dos variables enumeradas
        System.out.println("La comparativa de ambas variables es "+var1.compareTo(var2));
        


    }

}
