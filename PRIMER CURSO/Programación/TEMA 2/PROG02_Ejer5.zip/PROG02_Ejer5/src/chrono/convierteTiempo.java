/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package chrono;

import java.util.Scanner;

/**
 *
 * @author FELIPE
 */
public class convierteTiempo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int a, minutos, segundosF, horas, horasF, dias;
//creo las variables necesarias
        Scanner scn = new Scanner(System.in);
// creo un scanner para pedir datos 
        System.out.println("DAME UN NUMERO DE SEGUNDOS A CONVERTIR: ");
        a = scn.nextInt();
        System.out.println("convirtiendo....");
// Aqui estan las operaciones y restos necesarios para las multiples conversiones
        dias = a / 86400;
        int diasF = a % 86400;
        horas = diasF / 3600;
        horasF = diasF % 3600;
        minutos = horasF / 60;
        segundosF = horasF % 60;
// y aqui tenemos la impresion final
        System.out.println("LOS SEGUNDOS PROPORCIONADOS CONTIENEN....... ");
        System.out.println(dias + " Dias \n" + horas + " Horas \n" + minutos
                + " Minutos  \n" + segundosF + " Segundos");
    }

}
