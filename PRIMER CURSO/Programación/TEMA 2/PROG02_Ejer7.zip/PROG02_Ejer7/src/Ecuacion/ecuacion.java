/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Ecuacion;

import java.util.Scanner;

/**
 *
 * @author FELIPE
 */
public class ecuacion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        float C1, C2;
// Declaro un Scanner y las variables
        System.out.print("Introduzca un número: ");
        C1 = scn.nextInt();
        System.out.print("Introduzca otro número: ");
        C2 = scn.nextInt();
// Pido valores de las variables e imprimo la operacion
        System.out.printf("RESULTADO DE LA ECUACION ES:  %.1fx + %.1f = 0 es: %.4f", C1, C2, (-(C2 / C1)));
    }

}
