/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bisiestos;

import java.util.Scanner;

/**
 *
 * @author FELIPE
 */
public class bisiestos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
// Declaro una clse Scanner
        Scanner scn = new Scanner(System.in);
//pido dato
        System.out.println("Introduce un año");
        int anio = scn.nextInt();
// operacion con logica en un condicional que nos da una respuesta u otra
        if ((anio % 4 == 0 & anio % 100 != 0) || anio % 400 == 0) {
            System.out.println("ES BISIESTO");
        } else {
            System.out.println("NO ES BISIESTO");
        }

    }

}
