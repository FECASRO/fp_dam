/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author FELIPE
 */
public class clase {

    /**
     * @param args the command line arguments
     */
    public enum sexo {//creo la enumeracion que luego usare
        V, H
    }

    /*TODOS LOS DATOS LOS VAMOS A TRATAR DE MANERA INTERNA, CON LA CLASE SCANNER
TENDRIA LA POSIBILIDAD DE PEDIR DATOS CON LOS QUE INICIALIZARIA LA VARIABLE*/
    public static void main(String[] args) {

        final int cantidad_Fija = 5000;
        /* con final declaramos la variable como constante
         el tipo de variable "int" tiene un rango de valores de:
         -2,147,483,648 a 2,147,483,647 */
        boolean carnet = true;
        // Sólo puede tener 2 valores true o false
        byte mes_Numerido = 9;
        //una expresion entre 0 y 12 perfectamente entra en byte
        String mes_Anio = "Octubre";
        /*con String declaro una cadena en la que luego antes de imprimir 
puedo inicializar o pedir el dato por Scanner o dejar como null*/
        String nombre_Completo = "Felipe Castillo Rodriguez";
        //Aqui van el nombre y apellidos en una cadena de texto
        sexo persona = sexo.V;
        //aqui asigno a una variable persona una de las opciones del enum sexo

        long milisegundos = 1664323200000L;

// Los milisegundos transcurridos desde el 01/01/1970 52 años 9 meses y 13 dias
/*  52x365= 18.980 + 9x30=270 + 13 =  19263 dias x 24 horas = 462312 x 60 min = 27.738.720
27.738.720x 60 seg = 1.664.323.200 *1000= 1.664.323.200.000 esta tremenda cantidad 
seria reflejable con un tipo Long */
        float saldo = (float) 13500.56;
//Ojala necesitara double para el Saldo ....pero con float vale para poder 
//representar tb los decimales.
        double kms_Jupiter = 599000000.05;
        /* En Principio con float no valdria por lo que usaremos Double*/

        System.out.print("Cantidad fija: " + cantidad_Fija + "\n carnet: " 
+ carnet + "\n Mes Numerido: " + mes_Numerido + "\n Mes del Año: "+ mes_Anio +
 "\n Nombre Completo: "+nombre_Completo+ "\n Sexo de la persona: "+persona+
"\n Milisegundos desde 01-01-1970 hasta hoy: "+milisegundos+
"\n Saldo de la cuenta: "+ saldo+"\n Kilometros de la tierra a Jupiter: "
+kms_Jupiter);



    }

}
