/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package juegoedad;

import java.util.Scanner;

/**
 *
 * @author FELIPE
 */
public class juegoedad {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // voy a pedir edad por scanner y evaluarla a traves del operador terciario
        Scanner scn = new Scanner(System.in);
        int edad;
//pido edad con el scanner creado  
        System.out.println("Acontinuacion dame tu edad por favor: ");
        edad = scn.nextInt();
// aplico el operador terciario e imprimo el valor que corresponda
        String mayoria = (edad<18)? "Eres menor de edad" : "Eres mayor de edad";
        System.out.println(mayoria);
            
        }


    }


